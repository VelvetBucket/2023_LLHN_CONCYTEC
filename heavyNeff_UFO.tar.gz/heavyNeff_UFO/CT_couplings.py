# This file was automatically created by FeynRules 2.3.49
# Mathematica version: 12.3.1 for Linux x86 (64-bit) (June 19, 2021)
# Date: Fri 18 Mar 2022 10:22:14


from object_library import all_couplings, Coupling

from function_library import complexconjugate, re, im, csc, sec, acsc, asec, cot



