# This file was automatically created by FeynRules 2.3.49
# Mathematica version: 12.3.1 for Linux x86 (64-bit) (June 19, 2021)
# Date: Fri 18 Mar 2022 10:22:14


from object_library import all_orders, CouplingOrder


NP = CouplingOrder(name = 'NP',
                   expansion_order = 99,
                   hierarchy = 1)

QCD = CouplingOrder(name = 'QCD',
                    expansion_order = 99,
                    hierarchy = 1)

QED = CouplingOrder(name = 'QED',
                    expansion_order = 99,
                    hierarchy = 2)

QNP = CouplingOrder(name = 'QNP',
                    expansion_order = 2,
                    hierarchy = 1)

HIG = CouplingOrder(name = 'HIG',
                    expansion_order = 99,
                    hierarchy = 1)

HIW = CouplingOrder(name = 'HIW',
                    expansion_order = 99,
                    hierarchy = 1)

